using my.bookshop as db from '../db/schema';

service CatalogService @(odata.publish: true) {
  entity Products as projection on db.Products;
}