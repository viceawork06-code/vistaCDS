namespace my.bookshop;

entity Products {
  key ID    : UUID;
      name  : String(100);
      price : Decimal(9,2);
      stock : Integer;
}